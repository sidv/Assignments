x=10
y=20

div = lambda a,b: a/b
sum = lambda a,b: lambda: (lambda u,v:u/v)(int(a[0:2]) + b,b)
(lambda a,b: a/b)(10,20)

func = lambda a,b: (lambda u,v:u/v)(a,b)
func(x,y)


sum= lambda a,b : (lambda u,v: u+v+a+b)(40,30)

print(sum(x,y))


sum(x,y)(40,30)


sum(10,20)

lambda u,v : expression
lambda a=10,b=20: a+b #default arguments
lambda : function #No arguments

