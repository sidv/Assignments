students={
	"1":{
		"name":"Siddhant"
		"age":30
		"stream":"CS"
		}
	"2":{
                "name":"Pavan"
                "age":30
                "stream":"CS"
                }

}

students["1"] #{name:siddhant....}
students["1"]["name"] #Siddhant



for i ,j in students.items():
	#i 1 , 2
	#j {} {}
	#j["name"] j.get("name")

for i in students.keys():
	#statements

for i in students.values():
	#{}{}
	#i["name"]

i={name:siddhant,age:20,..}
i['name'] 
i['age']
i[stream]
siddhant | 20 | CS
