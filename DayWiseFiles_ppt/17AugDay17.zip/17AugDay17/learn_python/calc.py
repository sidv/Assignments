a = input("ENter num")
b = input("Enter num")

c = int(a) + int(b)
print(c)
