print("\tHello Sid")
print("\t\tThis is example")

print("This is \"firstline\" \nThis is nextline")
