print("______________________________________")
print("_______Variable______________________")
a = 10
b = 20
c = a + b
print(c)
name="Siddhant"
print(name)
print("______________________________________")
print("_________Take input from user_________")
a = input()
b = input("Enter number")
n = input("Enter name")
print(a)
print(b)
print(n)
