
class Fruit:
	def __init__(self,x,a,b):
		self.id = x
		self.name = a
		self.rate = b

#f1 = Fruit(1,"apple",20)
#f2 = Fruit(2,"mango",30)

