#parent class
class Car:
	def __init__(self,owner,manufacturing_date="",price=0,type=""):
		self.owner = owner
		self.manufactring_date = manufacturing_date
		self.price = price
		self.type = type
		
