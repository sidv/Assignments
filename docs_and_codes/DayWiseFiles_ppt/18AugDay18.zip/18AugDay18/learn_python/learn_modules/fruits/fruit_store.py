fruits = {}
