def sum(a,b):
	return a+b


add = lambda a,b:a+b

res = sum(10,20)
print(res)
res = (lambda a,b:a+b)(10,20)
print(res)

(lambda a,b:a-b)(30,40)


