#Print day of week
num =int(input("Enter day in number"))

if num == 1:
	print("Monday")
elif num == 2:
	print("Tuesday")
elif num == 3:
	print("Wednesday")
elif num == 4:
	print("Thursday")
else:
	print("Invalid choice")

