lst = ["Sid",10,20,40]
print(lst)
t = tuple(lst)
print(t)
data = (10,20)
print(data)
l = list(data)
print(l)

d = {
	"name":"Sid",
	"age":20
}
print(d)
l = list(d)
t = tuple(d)
print(l)
print(t)

l = list(d.values())
print(l)

#d = dict(lst)

name = "Siddhant"
print(list(name))

print(set(lst))
