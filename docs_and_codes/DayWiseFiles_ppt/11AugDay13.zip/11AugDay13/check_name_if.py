#Check name starts from "S"

name = input("Enter your name")

if name: #Check string is empty or not,If empty retuns false, If not empty returns true
	print("Its not empty")
else:
	print("Its empty")

#if name[0] == "S":
#	print("yes it starts from S")
#else:
#	print("No its not")
