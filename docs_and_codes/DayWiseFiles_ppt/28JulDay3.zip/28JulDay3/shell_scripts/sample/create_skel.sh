#!/bin/bash

mkdir -p "project/public/images"
mkdir -p "project/public/js"
mkdir -p "project/screens"
mkdir -p "project/components"
touch "project/index.html"
echo "Write your code here" > "project/index.html"

