#Check whether  you can vote or not

num = int(input("Enter your age"))

#Simple if
if ( num > 18 ) :
	print("You can vote")

#If - else
if ( num > 18 ):
	print("You can vote")
else:
	print("You can't vote")
#Elif 
if (num == 18):
	print("Now You can vote")
elif (num > 18):
	print("You can vote")
else:
	print("You can't vote")

