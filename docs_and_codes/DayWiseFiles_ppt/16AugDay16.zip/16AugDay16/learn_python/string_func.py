
#variable.func(arg)
#func(variable,arg)

#String functions:

name = "siddhant"
full_name = "SIDDHANT V"
#Syntax: variable.function(arg)

print(name.upper())  #Converts string to upper case
print(full_name.lower()) #Converts string to lower case
print(name.title()) #Converts first letter of string to upper case
print(name.isdigit()) #isdigit() returns true or false if string is digits
print("10".isdigit()) #true
print(name.islower()) # islower() returns true or false is string is in lower case or not
print(name.isupper()) # isupper() returns true or false is string is in upper case or not
