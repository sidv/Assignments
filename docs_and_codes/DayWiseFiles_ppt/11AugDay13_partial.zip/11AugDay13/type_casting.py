a = 10 #here 10 is number

b = "10" #Here 10 is string because its inside double quotes
c = '20' #Here it is also string because its inside single quotes

#Convert integer to string
print("_______Convert integer to string____________________")
print(str(a))

#Convert string to integer
print("_______Convert string to integer_____________________ ")
y = int(b)
print(y)
y= int(c)
print(c)
#Try to convert string to integer
name = "sid" 
print(int(name)) #Conversoion will fail because string must consist of digits

char = 'c'
print(int(char)) #Conversion failed

