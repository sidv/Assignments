#!/bin/bash

while read l
do
	echo $l
done < bio.txt

