#!/bin/bash

x=0
while true
do
	echo $x
	((x++))
done
