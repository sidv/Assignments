#!/bin/bash

echo 'First arg $1 : '$1
echo 'Second arg $2 :'$2
echo 'Count of arguments $# :'$#
echo 'ALl arg as single word $* :'$*
echo 'All arg as seperate word $@ :'$*
echo 'Last arg $_ :'$_
