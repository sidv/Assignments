#!/bin/bash

d=`date` #executing date command first
d=$(date) #executing date command first

user=$(whoami)
echo $user
