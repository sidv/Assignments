#!/bin/bash

echo '$# -> No of arguments : '$#
echo '$* -> All arguments as a single word : '$*
echo '$1 -> first arg : '$1
echo '$2 -> second arg : '$2
echo '$_ -> last arg : '$_
echo '$@ -> all arguments as separate words : '$@
echo '$0 -> command name : '$0
#echo $1
#echo $2
#echo $3
