#!/bin/bash


names=('Siddhant' 'Rajat' 'Neha' 'Raja' 'Pooja')

for i in "${names[@]}"
do
	echo $i
done
