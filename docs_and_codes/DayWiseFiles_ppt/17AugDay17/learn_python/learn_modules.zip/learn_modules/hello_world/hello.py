def welcome(name):
	print(f"Hello {name}!")

data = "This is the data"

def add(a,b):
	return a+b

def substract(a,b):
	return a-b
