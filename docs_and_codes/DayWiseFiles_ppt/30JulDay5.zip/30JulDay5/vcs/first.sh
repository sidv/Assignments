#!/bin/bash
cat cars.csv | cut -d"," -f1
name = "sid"
