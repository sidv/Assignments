#!/bin/bash
cat cars.csv | cut -d"," -f3
