#!/bin/bash

./second.sh
ls -l
