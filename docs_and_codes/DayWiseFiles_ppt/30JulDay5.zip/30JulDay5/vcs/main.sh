#!/bin/bash

./first.sh >>data.txt
./third.sh >> data.txt

